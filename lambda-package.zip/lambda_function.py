import json
import requests
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:  
        logger.info("-----")
        url = 'https://search-near-near-map-hepxii36cptigixna5itwgwbhi.ap-northeast-1.cloudsearch.amazonaws.com/2013-01-01/search?q=food&expr.distance=haversin(34.7277982,137.6691124,latlon.latitude,latlon.longitude)&return=distance,type,title&sort=distance%20asc'
        response = requests.get(url)
        
        return {
            'statusCode': 200,
            "body": json.dumps(response, ensure_ascii=False, indent=2)
        }

    except Exception as e:
        logger.exception(e)
        return {
            "statusCode": 500,
            "body": "error"
        }
